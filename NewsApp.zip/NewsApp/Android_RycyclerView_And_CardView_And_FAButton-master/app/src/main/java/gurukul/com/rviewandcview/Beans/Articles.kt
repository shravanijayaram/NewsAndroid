package gurukul.com.rviewandcview.Beans

data class Articles(
    val articles: List<Article>,
    val status: String,
    val totalResults: Int
)