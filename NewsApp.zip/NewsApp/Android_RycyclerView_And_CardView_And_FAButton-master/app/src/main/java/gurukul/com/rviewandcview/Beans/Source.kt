package gurukul.com.rviewandcview.Beans

data class Source(
    val id: String,
    val name: String
)