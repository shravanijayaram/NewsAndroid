package gurukul.com.rviewandcview

import gurukul.com.rviewandcview.Beans.Articles
import retrofit2.Call
import retrofit2.http.GET

interface NewsAPI {
    @GET("top-headlines?sources=google-news&apiKey=0248f3fbe1ee4f57b06e7d3942f3fd5d")
    fun getNews(): Call<Articles>
}